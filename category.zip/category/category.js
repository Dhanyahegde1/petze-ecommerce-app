document.addEventListener('DOMContentLoaded', function() {
    const categoryItems = document.getElementById('categoryItems');
    const animalButtons = document.querySelectorAll('.animal-btn');
  
    const itemsByCategory = {
     
      dog: {
       
        treat: [
          { name: 'American natural premium', cost: 400, image: "./picture/pf.webp" ,link:"prodamerican.html"},
          { name: 'Pedigree', cost: 314, image: "./picture/pedigree.jpg",link:"prodpedigree.html" },
          { name: 'Dog collar', cost: 459, image: "./picture/dog collar.jpg",link:"prodcollar.html" },
          { name: 'Kibble', cost: 299, image: "./picture/kibble.webp ",link:"prodkibble.html" },
          { name: 'Dog Leash', cost: 500, image: "./picture/leash.webp" },
          { name:'Dog Biscuits', cost: 200, image: "./picture/do bis.jpeg" },
          
      ]
     },
      cat: {
        treat: [
          { name: 'Meomix Cat Treats', cost: 180, image: './picture/meomix.webp', link:"prodmeow.html" },
          { name: 'Drools', cost: 250, image: './picture/Drools.jpg' ,link:"proddrools.html"},
          { name: 'bow', cost: 450, image: './picture/access.webp' ,link:"prodbow.html"},
          { name: 'Cat Bed', cost: 799, image: './picture/catbed.webp',link:"prodbow.html" },
          { name: 'Cat brush', cost: 399, image: './picture/brush.webp' },
          { name: 'bandana combo', cost: 159, image: './picture/bow.jpg',link:"prodbow.html" },

        ]
      },
      fish: {
        treat: [

          { name: 'Tropical Fish food', cost: 1500, image: './picture/aquariumfood.webp',link:"prodtropical.html"  },
          { name: 'Chichlid chips', cost: 150, image: './picture/fishfood1.jpg',link:"prodchips.html" },
          { name: 'Filter Cartridge', cost: 2200, image: './picture/filter.webp',link:"prodfilter.html" },
          { name: 'Fish Oil', cost: 399, image: './picture/fishsupp.webp',link:"prodfishsupp.html" },
          { name: 'Internal power filter', cost: 3000, image: './picture/internfilter.webp' },
          { name: 'mini algae wafers', cost: 165, image: './picture/wafers.webp' },
          
        ],
       

      },
      birds: {
        treat: [
          { name: ' Bird Seed', cost: 200, image: './picture/birdfood.jpg' ,link : "productbird.html" },
          { name: 'Bird feeder', cost: 300, image: './picture/birdfeeder.webp' ,link : "prodbird2.html"},
          { name: 'Bird cage', cost: 1599, image: './picture/cage1.jpg',link:"prodcage.html" },
          { name: 'Premium bird seeds', cost: 1000, image: './picture/premium.jpg' },
          { name: 'Bird accessories', cost: 1000, image: './picture/birdaccess.jpg' },
          { name: 'wild birds food', cost: 300, image: './picture/wild.jpeg' },
        ],
      },
      Hospital:{
        treat: [
        { name: 'Pleasent valley veterinary clinic',cost : 300, image:'./picture/hospital-building.jpg',link : "prodhos1.html"},
        { name: 'Annmees veterinary hospital',cost : 200, image: './picture/annmees.webp', link:"prodhos2.html"},
        { name: 'Taunton road hospital',cost : 500,  image: './picture/hos2.jpg' ,link : "prodhos3.html"},
        { name: 'Paws & Tails animal hospital', cost : 250, image: './picture/PawsTailshosp.jpg'  },
        { name: 'Banafield pet hospital',cost : 350,  image: './picture/banafield.jpg' },
        { name: 'Hwak ridge animal hospital',cost : 400, image: './picture/hwakhosp.jpg' },
       
      ],
    },

    };
  
    function renderCategoryItems(animal, category) {
      categoryItems.innerHTML = '';
      itemsByCategory[animal][category].forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.classList.add('category-item');
        itemElement.innerHTML = `
        
         <img src="${item.image}" alt="${item.name}">
         <a href = "${item.link}" alt="${item.link}">
          <h2>${item.name}</h2>
          <p>Cost: ₹${item.cost}</p>
        `;
        categoryItems.appendChild(itemElement);
      });
    }
  
    animalButtons.forEach(button => {
      button.addEventListener('click', function() {
        const animal = this.getAttribute('data-animal');
        renderCategoryItems(animal, 'treat'); // Default to treat category
      });
    });
  });
