<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pet Shop - Category Page</title>
  <link rel="stylesheet" href="category.css">
</head>
<body>
  <header class="header">
     <section class="flex">
      <a href="#" style="display: flex; font-size:xx-large;" class="logo"><b>PETZEE</b> </a>
    <h1>Welcome to PETZEE</h1>
    <h4>Select a category to explore our product</h4>
    <a href="home.html" style="font-size:larger;">Home</a>
    <a href="view_products.php" style="font-size:larger;">Shop</a>
    <a href="shopping_cart.php"style="font-size:larger;" class="cart-btn">cart<span><?php= $total_cart_items; ?></span></a>
    </section>
  </header>
  <br>
  <main>
    <div class="animals">
      <button class="animal-btn" data-animal="dog">Dog</button>
      <button class="animal-btn" data-animal="cat">Cat</button>
      <button class="animal-btn" data-animal="fish">Fish</button>
      <button class="animal-btn" data-animal="birds">Birds</button>
      <button class="animal-btn" data-animal="Hospital">Hospital</button>
    </div>
    <br>
    <div id="categoryItems" class="category-items">
      <!-- Items will be dynamically added here -->
    </div>
    <div class="shopping-options">
      <h2>Shopping Options</h2>
      <ul>
        <li>Daily Deals</li>
        <li>Free Shipping</li>
        <li>Easy Returns</li>
        <li>24/7 Support</li>
      </ul>
    </div>
  </main>

  <!-- 
        - #BRAND
      -->

      <section class="section brand" aria-label="brand">
        <div class="container">

          <h2 class="h2 section-title">
            <span class="span">Popular</span> Brands
          </h2>

          <ul class="has-scrollbar">

            <li class="scrollbar-item">
              <div class="brand-card img-holder" style="--width: 150; --height: 150;">
                <img src=" ./picture/brand-1.jpg" width="150" height="150" loading="lazy" alt="brand logo"
                  class="img-cover">
              </div>
            </li>

            <li class="scrollbar-item">
              <div class="brand-card img-holder" style="--width: 150; --height: 150;">
                <img src="./picture/Market.png" width="150" height="150" loading="lazy" alt="brand logo"
                  class="img-cover">
              </div>
            </li>

            <li class="scrollbar-item">
              <div class="brand-card img-holder" style="--width: 150; --height: 150;">
                <img src="./picture/brand-3.webp" width="150" height="150" loading="lazy" alt="brand logo"
                  class="img-cover">
              </div>
            </li>

            <li class="scrollbar-item">
              <div class="brand-card img-holder" style="--width: 150; --height: 150;">
                <img src="./picture/paws.png" width="150" height="150" loading="lazy" alt="brand logo"
                  class="img-cover">
              </div>
            </li>

            <li class="scrollbar-item">
              <div class="brand-card img-holder" style="--width: 150; --height: 150;">
                <img src="./picture/brand-4.jpg" width="150" height="150" loading="lazy" alt="brand logo"
                  class="img-cover">
              </div>
            </li>

          </ul>

        </div>
      </section>

    </article>
  </main>

<!-- 
    - #FOOTER
  -->
  <br>
  <br>
  <br>
  
    <footer class="footer" style="background-image: url('')">
  
      <div class="footer-top section">
        <div class="container">
  
          <div class="footer-brand">
  
            <a href="#" class="logo">PETZEE</a>
  
            <p class="footer-text">
              If you have any question, please contact us at <a href="mailto:support@gmail.com"
                class="link">support@gmail.com</a>
            </p>
  
            <ul class="contact-list">
  
              <li class="contact-item">
                <ion-icon name="location-outline" aria-hidden="true"></ion-icon>
  
                <address class="address">
                   banglore karnataka
                </address>
              </li>
  
              <li class="contact-item">
                <ion-icon name="call-outline" aria-hidden="true"></ion-icon>
  
                <a href="tel:+16234567891011" class="contact-link">9645871256</a>
              </li>
  
            </ul>
  
            <ul class="social-list">
  
              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-facebook"></ion-icon>
                </a>
              </li>
  
              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-twitter"></ion-icon>
                </a>
              </li>
  
              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-pinterest"></ion-icon>
                </a>
              </li>
  
              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-instagram"></ion-icon>
                </a>
              </li>
  
            </ul>
  
          </div>
  
          <ul class="footer-list">
  
            <li>
              <p class="footer-list-title">Corporate</p>
            </li>
  
            <li>
              <a href="#" class="footer-link">Careers</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">About Us</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Contact Us</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">FAQs</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Vendors</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Affiliate Program</a>
            </li>
  
          </ul>
  
          <ul class="footer-list">
  
            <li>
              <p class="footer-list-title">Information</p>
            </li>
  
            <li>
              <a href="#" class="footer-link">Online Store</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Privacy Policy</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Refund Policy</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Shipping Policy</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Terms of Service</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Track Order</a>
            </li>
  
          </ul>
  
          <ul class="footer-list">
  
            <li>
              <p class="footer-list-title">Services</p>
            </li>
  
            <li>
              <a href="#" class="footer-link">Grooming</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Positive Dog Training</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Veterinary Services</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Petco Insurance</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Pet Adoption</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Resource Center</a>
            </li>
  
          </ul>
  
        </div>
      </div>
  
      <div class="footer-bottom">
        <div class="container">
  
          <p class="copyright">
            &copy; all copyrights reserved <a href="#" class="copyright-link">.</a>
          </p>
  
          <img src="./picture/payment.png" width="397" height="32" loading="lazy" alt="payment method" class="img">
  
        </div>
      </div>
  
    </footer>

  <script src="category.js"></script>
</body>
</html>
