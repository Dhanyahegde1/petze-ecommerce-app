<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   setcookie('user_id', create_unique_id(), time() + 60*60*24*30);
}

if(isset($_POST['add_to_cart'])){

   $id = create_unique_id();
   $product_id = $_POST['product_id'];
   $product_id = filter_var($product_id, FILTER_SANITIZE_STRING);
   $qty = $_POST['qty'];
   $qty = filter_var($qty, FILTER_SANITIZE_STRING);
   
   $verify_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ? AND product_id = ?");   
   $verify_cart->execute([$user_id, $product_id]);

   $max_cart_items = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
   $max_cart_items->execute([$user_id]);

   if($verify_cart->rowCount() > 0){
      $warning_msg[] = 'Already added to cart!';
   }elseif($max_cart_items->rowCount() == 10){
      $warning_msg[] = 'Cart is full!';
   }else{

      $select_price = $conn->prepare("SELECT * FROM `products` WHERE id = ? LIMIT 1");
      $select_price->execute([$product_id]);
      $fetch_price = $select_price->fetch(PDO::FETCH_ASSOC);

      $insert_cart = $conn->prepare("INSERT INTO `cart`(id, user_id, product_id, price, qty) VALUES(?,?,?,?,?)");
      $insert_cart->execute([$id, $user_id, $product_id, $fetch_price['price'], $qty]);
      $success_msg[] = 'Added to cart!';
   }

}

?>








<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="product.css">
    <script src="https://kit.fontawesome.com/f30fac2c61.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="card">
        <div class="img">
            <img src="./picture/pf.webp" alt="" onclick="clk(this)"> <br>
            <img src="./picture/p.webp" alt=""   onclick="clk(this)"> <br>
            <img src="#" alt=""  onclick="clk(this)"> <br>
            <img src="#" alt=""  onclick="clk(this)"> <br>
            <img src="#" alt=""  onclick="clk(this)"> <br>

        </div>
        <div class="left">
            <img src="./picture/pf.webp" id="imgs" alt="">
        </div>

        <div class="right">
            <h3>American natural premium</h3>
            <h1>Dog food-American natural premium</h1>
            <h1>₹400</h1>
            <i class="fa-solid fa-star"></i>
            <i class="fa-solid fa-star"></i>
            <i class="fa-solid fa-star"></i>
            <i class="fa-solid fa-star"></i>
            <i class="fa-solid fa-star-half-stroke"></i>
            <h3>Brand : Market Fresh</h3>
            <h4>Available Offer's</h4>
            <p>: Special PriceGet extra 11% off (price inclusive of cashback/coupon)</p>
            <p>: Partner OfferPurchase now & get a surprise cashback coupon for May / June 2024</p>
            <p>: Partner OfferSign up for Razer Pay Later and get Gift Card worth up to ₹1000*</p>
            <p>: Bank Offer5% Cashback on Axis Bank            </p>
            <a href="shopingcart/shopping_cart.php" class="cart-btn"><button>Add To Cart</button></a>
             
             <button>Buy Now</button>

        </div>
    </div>

<!-- 
    - #FOOTER
  -->
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
    <footer class="footer" style="background-image: url('')">
  
      <div class="footer-top section">
        <div class="container">
  
          <div class="footer-brand">
  
            <a href="#" class="logo">PETZEE</a>
  
            <p class="footer-text">
              If you have any question, please contact us at <a href="mailto:support@gmail.com"
                class="link">support@gmail.com</a>
            </p>
  
            <ul class="contact-list">
  
              <li class="contact-item">
                <ion-icon name="location-outline" aria-hidden="true"></ion-icon>
  
                <address class="address">
                   banglore karnataka
                </address>
              </li>
  
              <li class="contact-item">
                <ion-icon name="call-outline" aria-hidden="true"></ion-icon>
  
                <a href="tel:+16234567891011" class="contact-link">9645871256</a>
              </li>
  
            </ul>
  
            <ul class="social-list">
  
              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-facebook"></ion-icon>
                </a>
              </li>
  
              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-twitter"></ion-icon>
                </a>
              </li>
  
              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-pinterest"></ion-icon>
                </a>
              </li>
  
              <li>
                <a href="#" class="social-link">
                  <ion-icon name="logo-instagram"></ion-icon>
                </a>
              </li>
  
            </ul>
  
          </div>
  
          <ul class="footer-list">
  
            <li>
              <p class="footer-list-title">Corporate</p>
            </li>
  
            <li>
              <a href="#" class="footer-link">Careers</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">About Us</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Contact Us</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">FAQs</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Vendors</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Affiliate Program</a>
            </li>
  
          </ul>
  
          <ul class="footer-list">
  
            <li>
              <p class="footer-list-title">Information</p>
            </li>
  
            <li>
              <a href="#" class="footer-link">Online Store</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Privacy Policy</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Refund Policy</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Shipping Policy</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Terms of Service</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Track Order</a>
            </li>
  
          </ul>
  
          <ul class="footer-list">
  
            <li>
              <p class="footer-list-title">Services</p>
            </li>
  
            <li>
              <a href="#" class="footer-link">Grooming</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Positive Dog Training</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Veterinary Services</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Petco Insurance</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Pet Adoption</a>
            </li>
  
            <li>
              <a href="#" class="footer-link">Resource Center</a>
            </li>
  
          </ul>
  
        </div>
      </div>
  
      <div class="footer-bottom">
        <div class="container">
  
          <p class="copyright">
            &copy; all copyrights reserved <a href="#" class="copyright-link">.</a>
          </p>
  
          <img src="./picture/payment.png" width="397" height="32" loading="lazy" alt="payment method" class="img">
  
        </div>
      </div>
  
    </footer>

    <script>
        function clk(newImg){
            let getImg=document.getElementById("imgs");
            getImg.src=newImg.src;
        }
    </script>
</body>
</html>