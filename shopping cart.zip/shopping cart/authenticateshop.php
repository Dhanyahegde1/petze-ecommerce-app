<?php
include('dbconnect.php');

if (isset($_POST['submit'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $email = stripslashes($email);
    $password = stripcslashes($password);

    $email = mysqli_real_escape_string($conn,$email);
    $password = mysqli_real_escape_string($conn, $password);

    $query=mysqli_query($conn, "select * from shops where email= '$email' and password='$password'");
    $rows = mysqli_num_rows($query);
    if($rows == 1){
       include('admin.php');
    }      
    else{
        echo "login failed";
    }
}
?>
