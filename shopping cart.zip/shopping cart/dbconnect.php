<?php
$conn=mysqli_connect("localhost","root","","swiss_collection");
// if(!$conn){
//     echo " not connected";
// }
// else{
//     echo "successfully connected";
// }
?>