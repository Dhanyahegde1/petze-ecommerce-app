<header class="header">

   <div class="flex">

      <a href="#" class="logo">PETZEE</a>

      <nav class="navbar">
         <a href="admin.php">add products</a>
         <a href="products.php">view products</a>
      </nav>
      

      <div id="menu-btn" class="fas fa-bars"></div>

   </div>

</header>