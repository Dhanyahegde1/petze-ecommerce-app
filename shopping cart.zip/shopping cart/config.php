<?php

$conn = mysqli_connect('localhost','root','','swiss_collection') or die('connection failed');

?>